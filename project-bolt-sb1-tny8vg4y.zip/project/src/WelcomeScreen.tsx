import React from 'react';
import { Beaker, ArrowRight } from 'lucide-react';

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center z-50 relative">
      {/* Company Logo Watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
        <h1 className="text-[20rem] font-black text-indigo-900 select-none">EGYBEV</h1>
      </div>
      
      <div className="bg-white/90 backdrop-blur-sm p-8 rounded-2xl shadow-2xl max-w-2xl w-full mx-4 relative z-10">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="bg-indigo-100 p-4 rounded-full">
              <Beaker className="w-16 h-16 text-indigo-600" />
            </div>
          </div>
          
          <div className="mb-6">
            <h2 className="text-xl text-indigo-600 font-semibold mb-2">مرحباً بكم في</h2>
            <h1 className="text-4xl font-bold text-indigo-900 mb-4">
              حاسبة المشروبات الروحية
            </h1>
            <div className="text-lg text-gray-600 leading-relaxed space-y-2">
              <p className="font-semibold text-indigo-800">
                تم تطوير وتصميم هذا التطبيق بواسطة
              </p>
              <p className="text-2xl font-bold text-indigo-700">
                مينا محروس
              </p>
              <p className="text-gray-500 italic">
                EGYBEV شركة
              </p>
            </div>
          </div>

          <p className="text-gray-600 text-lg leading-relaxed">
            أداة احترافية لحساب وتعديل تركيز الكحول بدقة عالية، مع معلومات تعليمية شاملة عن المشروبات الروحية المختلفة.
          </p>
        </div>

        <button
          onClick={onGetStarted}
          className="w-full bg-indigo-600 text-white py-4 px-6 rounded-xl font-semibold text-lg hover:bg-indigo-700 transition-all duration-300 flex items-center justify-center group hover:scale-[1.02]"
        >
          ابدأ الآن
          <ArrowRight className="mr-2 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
}